import cv2

n = cv2.__version__

print n