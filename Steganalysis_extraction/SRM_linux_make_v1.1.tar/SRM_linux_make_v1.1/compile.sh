#!/bin/bash

kerType=$(uname -m)
if [ "${kerType}" == "x86_64" ]; then
	libsPath="../lib/GLNXA64"
elif [ "${kerType}" == "i686" ]; then
    libsPath="../lib/GLNX86"
else
	echo "Something is wrong with system identification"
fi

# release
cd release
g++ -o3 -Wall ../SRM_src/SRM.cpp ../SRM_src/SRMclass.cpp ../SRM_src/submodel.cpp ../SRM_src/image.cpp ../SRM_src/s.cpp -o SRM -I../include -L${libsPath} -lboost_program_options-mt -lboost_filesystem-mt -lboost_system-mt

# debug
cd ../debug
g++ -ggdb -Wall ../SRM_src/SRM.cpp ../SRM_src/SRMclass.cpp ../SRM_src/submodel.cpp ../SRM_src/image.cpp ../SRM_src/s.cpp -o SRM -I../include -L${libsPath} -lboost_program_options-mt -lboost_filesystem-mt -lboost_system-mt
