% This compile.m is used under Linux
clc;
fprintf('compiling SRM ... ');

mex -O -largeArrayDims -output SRM SRM_matlab.cpp SRMclass.cpp submodel.cpp s.cpp image.cpp exception.cpp config.cpp

fprintf('done\n');
copyfile('*.mex*','../matlab');
fprintf('Compiled SRM MEX file was copied to ../matlab folder.\n');
