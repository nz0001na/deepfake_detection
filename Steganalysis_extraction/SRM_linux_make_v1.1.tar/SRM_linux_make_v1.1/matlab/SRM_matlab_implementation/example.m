clc; clear all;

% Specify all images for extraction
ImageSet = {'../images/1.pgm', ...
            '../images/2.pgm', ...
            '../images/3.pgm', ...
            '../images/4.pgm', ...
            '../images/5.pgm'};

%% ---------------------------
% SRM extraction by MATLAB 
% ----------------------------
fprintf('SRM extraction');
F = cell(numel(ImageSet), 1);
startAll = tic;
for imageIndex=1:numel(ImageSet)
    fprintf('\n%d. image', imageIndex);
    startOne = tic;
    F{imageIndex} = SRM(ImageSet{imageIndex});
    endOne = toc(startOne);
    fprintf(' - processed in %.2f seconds', endOne);
end
endAll = toc(startAll);
fprintf('\nOSRM processed %d images in %.2f seconds, in average %.2f seconds per image\n', numel(ImageSet), endAll, endAll / numel(ImageSet));
fprintf('\n"F{1}" contains following submodel features (feature dimension): \n');
Ss = fieldnames(F{1});
for Sid = 1:length(Ss)
    Fsingle = eval(['F{1}.' Ss{Sid}]);
    fprintf('   F{1}.%s : %d\n', Ss{Sid}, size(Fsingle, 2));
end